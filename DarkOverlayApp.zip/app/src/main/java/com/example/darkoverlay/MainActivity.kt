package com.example.darkoverlay

import android.graphics.PixelFormat
import android.os.Bundle
import android.view.*
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import android.content.Context
import android.widget.LinearLayout

class MainActivity : AppCompatActivity() {
    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: View
    private var isOverlayVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val toggleButton = Button(this).apply {
            text = "Toggle Dark Overlay"
            setOnClickListener {
                if (isOverlayVisible) removeOverlay() else showOverlay()
            }
        }

        layout.addView(toggleButton)
        setContentView(layout)
    }

    private fun showOverlay() {
        overlayView = View(this).apply {
            setBackgroundColor(0xAA000000.toInt())
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager.addView(overlayView, params)
        isOverlayVisible = true
    }

    private fun removeOverlay() {
        if (::overlayView.isInitialized) {
            windowManager.removeView(overlayView)
            isOverlayVisible = false
        }
    }
}